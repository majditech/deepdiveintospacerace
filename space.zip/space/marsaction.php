<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MARS IMAGES | MAJDI AWAD</title>
<style type="text/css">
.result {
	background-color:rgba(0, 0, 0, 0.5);
	color:#fff;
	font-family:"Century Gothic";
	margin:auto;
	width:500px;
	padding:20px;
}
.body {
  background-image: url("marssearch.png");
  background-repeat: no-repeat;
  background-attachment: fixed;
}
            .link {
                width:250px;
                height:50px;
                margin-top:10px;  
                background-color:#fff;
                color:#351306;
                font-size:16px;
                font-family:"Century Gothic";
</style>
</head>

<body class="body">
<div class="result">
	<?php

$servername = "localhost";
$username = "googlitt_mars";
$password = "Majdi@00800";
$database = "googlitt_mars";

$conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) {
        
        die("connection failed: " . $conn->connect_error);
    }

    if(isset($_GET['attitude'])) {
        
        $attitude = $_GET['attitude'];
        $date = $_GET['date'];
        $title = $_GET['title'];
        $filter = $_GET['filter'];
        $instrument = $_GET['instrument'];
        $model = $_GET['model'];
        $query = $conn->query("SELECT attitude, caption, taken_mars, credit, date, taken_utc, link, title, received, image, filter, instrument, model FROM mars WHERE attitude LIKE '%{$attitude}%' AND date LIKE '%{$date}%' AND title LIKE '%{$title}%' AND filter LIKE '%{$filter}%' AND instrument LIKE '%{$instrument}%' AND model LIKE '%{$model}%'");
        ?>
        <div><?php echo $query->num_rows; ?> IMAGE FOUNDED<br><br>
        
        <?php
        
        if($query->num_rows) {
            while($r = $query->fetch_object()) {
            ?>
            <strong>TITLE: </strong><?PHP echo $r->title; ?><br>
            <strong>LINK: </strong><a style="color:#fff;" href="<?php echo $r->link; ?>">CHECK IT</a><br>
            <strong>LOCATION: </strong><?PHP echo $r->attitude; ?><br>
            <strong>CAPTION: </strong><?PHP echo $r->caption; ?><br>
            <strong>DATA TAKEN MARS: </strong><?PHP echo $r->taken_mars; ?><br>
            <strong>credit: </strong><?PHP echo $r->credit; ?><br>
            <strong>DATE: </strong><?PHP echo $r->date; ?><br>
            <strong>DATA TAKEN UTC: </strong><?PHP echo $r->taken_utc; ?><br>
            <strong>RECEIVED: </strong><?PHP echo $r->received; ?><br>
            <strong>image: </strong><a style="color:#fff;" href="<?php echo $r->image; ?>">CHECK IT</a><br>
            <strong>FILTER: </strong><?PHP echo $r->filter; ?><br>
            <strong>INSTRUMENT: </strong><?PHP echo $r->instrument; ?><br>
            <strong>MODEL: </strong><?PHP echo $r->model; ?><br>
            <form action="mars.php">
            <input class="link" type="submit" value="BACK TO SEARCH">
            </form><br>
            <hr>







            <?php

            }
        }
    }
?>
</div>
</body>

</html>
