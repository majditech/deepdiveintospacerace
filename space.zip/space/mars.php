<html>
    <head>
        <title>MARS | MAJDI AWAD</title>
        <style type="text/css">
        .body {
	       background-image:url('mars.png');
           background-position:center;
	       background-repeat:no-repeat;
	       background-attachment: fixed;
            }
        .marssearch {
            background-color:rgba(0, 0, 0, 0.5);
            color:#fff;
	        font-family:"Century Gothic";
	        margin:auto;
	        width:300px;
	        padding:20px;
        }
        .input {
            width:250px;
            height:50px;
            margin:10px;
            font-family:"Century Gothic";
        }
        .link {
            width:250px;
            height:50px;
            margin:10px;
            font-family:"Century Gothic";
            background-color:#351306;
            color:#fff;
        }
        </style>
    </head>
    <body class="body">
        <div align="center" class="marssearch">
            <div>This dataset consist more than 118976 images for MARS from NASA. You can search by multi methods and we will improve it everyday. All images will from 2021 until 4/8/2021.</div>
            <form action="marsaction.php" method="get">
                <input class="input" type="text" name="attitude" placeholder="SEARCH BY ATTITUDE IF YOU KNOW IT">
                <input class="input" type="text" name="date" placeholder="M/D/YYYY">
                <input class="input" type="text" name="title" placeholder="SEARCH BY IMAGE NAME">
                <select class="input" name="filter">
                    <option value="" disabled selected hidden>SEARCH BY CAMERA FILTER</option>
                    <option>UNK</option>
                    <option>UNK</option>
                    <option>OPEN</option>
                    <option>ZCAM_R0_RGB</option>
                    <option>ZCAM_L0_RGB</option>
                    <option>ZCAM_R7_880NM_ND5</option>
                    <option>ZCAM_L7_RGB_ND6</option>
                    <option>ZCAM_R6_1022NM</option>
                    <option>ZCAM_L6_442NM</option>
                    <option>ZCAM_R5_978NM</option>
                    <option>ZCAM_L5_528NM</option>
                    <option>ZCAM_R4_939NM</option>
                    <option>ZCAM_L4_605NM</option>
                    <option>ZCAM_R3_910NM</option>
                    <option>ZCAM_L3_677NM</option>
                    <option>ZCAM_R2_866NM</option>
                    <option>ZCAM_L2_754NM</option>
                    <option>ZCAM_R1_800NM</option>
                    <option>ZCAM_L1_800NM</option>
                </select>
                <select class="input" name="instrument">
                        <option value="" disabled selected hidden>SEARCH BY CAMERA INSTRUMENT</option>
                        <option>SHERLOC_ACI</option>
                        <option>SHERLOC_WATSON</option>
                        <option>FRONT_HAZCAM_RIGHT_A</option>
                        <option>FRONT_HAZCAM_LEFT_A</option>
                        <option>NAVCAM_LEFT</option>
                        <option>NAVCAM_RIGHT</option>
                        <option>MCZ_RIGHT</option>
                        <option>MCZ_LEFT</option>
                        <option>SUPERCAM_RMI</option>
                        <option>PIXL_MCC</option>
                        <option>SKYCAM</option>
                        <option>REAR_HAZCAM_LEFT</option>
                        <option>REAR_HAZCAM_RIGHT</option>
                        <option>EDL_PUCAM2</option>
                        <option>EDL_RDCAM</option>
                        <option>EDL_RUCAM</option>
                        <option>EDL_DDCAM</option>
                        <option>CACHECAM</option>
                        <option>EDL_PUCAM1</option>
                        <option>LCAM</option>
                </select>
                <select class="input" name="model">
                    <option value="" disabled selected hidden>SEARCH BY CAMERA MODEL</option>
                    <option>CAHVOR</option>
                    <option>CAHVORE</option>
                    <option>CAHV</option>
                    <option>UNK</option>
                    <option>NONE</option>
                </select>
                <input class="link" type="submit" name="submit" value="SEARCH FOR IMAGES">
            </form>
            <form action="index.php">
                <input class="link" type="submit" value="BACK HOME">
            </form>
        </div>
    </body>
</html>