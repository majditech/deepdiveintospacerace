<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Deep Dive in the Space Race | MAJDI AWAD</title>
<style type="text/css">
.result {
	background-color:rgba(0, 0, 0, 0.5);
	color:#fff;
	font-family:"Century Gothic";
	margin:auto;
	width:500px;
	padding:20px;
}
.body {
  background-image: url("location.jpg");
  background-repeat: no-repeat;
  background-attachment: fixed;
}
            .link {
                width:250px;
                height:50px;
                margin-top:10px;  
                background-color:#fff;
                color:#351306;
                font-size:16px;
                font-family:"Century Gothic";
</style>
</head>

<body class="body">
<div class="result">
	<?php

$servername = "localhost";
$username = "googlitt_space";
$password = "Majdi@0080010455";
$database = "googlitt_space";

$conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) {
        
        die("connection failed: " . $conn->connect_error);
    }

    if(isset($_GET['location'])) {
        
        $location = $_GET['location'];
        $query = $conn->query("SELECT company, location, date, detail, status_rocket, rocket, status FROM space WHERE location LIKE '%{$location}%'");
        ?>
        <div><?php echo $query->num_rows; ?> Missions Founded for your search about <?php echo $location; ?> in our dataset. Note that the dataset contains data until Aug 07, 2020.<br><br>
        
        <?php
        
        if($query->num_rows) {
            while($r = $query->fetch_object()) {
            ?>
            
            <strong><?php echo $r->company; ?></strong><br>
            <strong>LOCATION: <?php echo $r->location; ?></strong> | <?php echo $r->date; ?><br>
            <p align="justify"><?php echo $r->detail; ?></p><br>
            <strong>ROCKET STATUS: <?php echo $r->status_rocket; ?></strong> | <strong>ROCKET: <?php echo $r->rocket; ?></strong> |
            <strong>MESSION STATUS: <?php echo $r->status; ?></strong><br><form action="index.php"><input class="link" type="submit" value="BACK TO SEARCH"></form><hr><br>
            <?php

            }
        }
    }
?>
</div>
</body>

</html>
