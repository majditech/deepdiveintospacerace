<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Compare Between Companies | Deep Dive in the Space Race | MAJDI AWAD</title>
<style type="text/css">
                .body {
	            background-image:url('compare.jpg');
            	background-position:center;
	            background-repeat:no-repeat;
	            background-attachment: fixed;
                }
                .compare {
    background-color:rgba(0, 0, 0, 0.5);
	color:#fff;
	font-family:"Century Gothic";
	width:300px;
	padding:20px;
	height:100%;

                }
    .select {
        width:250px;
        height:50px;
        font-family:"Century Gothic";
        margin:10px;
    }
    .link {
                width:250px;
                height:50px;
                margin-top:10px;  
                background-color:#351306;
                color:#fff;
                font-size:16px;
                font-family:"Century Gothic";
    }
</style>
</head>

<body class="body">
<div align="center" class="compare">
    <div style="font-size:14px;">PLEASE SELECT THE COMPANIES THAT YOU WANT TO COMPARE, THEN SELECT THE STATUS. THE RESULT WILL SHOW THE NUMBER OF THE MAITONS FOR BOTH COMAPNIES BASED ON THE STATUS THAT YOU HAVE SELECT.</div><br>
    <form action="#" method="get">
<select class="select" name="company">
                    <option value="" disabled selected hidden>FIRST COMPANY</option>
	<option>SpaceX</option>
                <option>CASC</option>
                <option>Roscosmos</option>
                <option>ULA</option>
                <option>JAXA</option>
                <option>Northrop</option>
                <option>ExPace</option>
                <option>IAI</option>
                <option>Rocket Lab</option>
                <option>Virgin Orbit</option>
                <option>VKS RF</option>
                <option>MHI</option>
                <option>IRGC</option>
                <option>Arianespace</option>
                <option>ISA</option>
                <option>Blue Origin</option>
                <option>ISRO</option>
                <option>Exos</option>
                <option>ILS</option>
                <option>i-Space</option>
                <option>OneSpace</option>
                <option>Landspace</option>
                <option>Eurockot</option>
                <option>Land Launch</option>
                <option>CASIC</option>
                <option>KCST</option>
                <option>Sandia</option>
                <option>Kosmotras</option>
                <option>Khrunichev</option>
                <option>Sea Launch</option>
                <option>KARI</option>
                <option>ESA</option>
                <option>NASA</option>
                <option>Boeing</option>
                <option>ISAS</option>
                <option>SRC</option>
                <option>MITT</option>
                <option>Lockheed</option>
                <option>AEB</option>
                <option>Starsem</option>
                <option>RVSN USSR</option>
                <option>EER</option>
                <option>General Dynamics</option>
                <option>Martin Marietta</option>
                <option>Yuzhmash</option>
                <option>Douglas</option>
                <option>ASI</option>
                <option>US Air Force</option>
                <option>CNES</option>
                <option>CECLES</option>
                <option>RAE</option>
                <option>UT</option>
                <option>OKB-586</option>
                <option>AMBA</option>
                <option>Arm??e de l'Air</option>
                <option>US Navy</option>
</select>
<select class="select" name="company2">
                    <option value="" disabled selected hidden>SECOND COMPANY</option>
	<option>SpaceX</option>
                <option>CASC</option>
                <option>Roscosmos</option>
                <option>ULA</option>
                <option>JAXA</option>
                <option>Northrop</option>
                <option>ExPace</option>
                <option>IAI</option>
                <option>Rocket Lab</option>
                <option>Virgin Orbit</option>
                <option>VKS RF</option>
                <option>MHI</option>
                <option>IRGC</option>
                <option>Arianespace</option>
                <option>ISA</option>
                <option>Blue Origin</option>
                <option>ISRO</option>
                <option>Exos</option>
                <option>ILS</option>
                <option>i-Space</option>
                <option>OneSpace</option>
                <option>Landspace</option>
                <option>Eurockot</option>
                <option>Land Launch</option>
                <option>CASIC</option>
                <option>KCST</option>
                <option>Sandia</option>
                <option>Kosmotras</option>
                <option>Khrunichev</option>
                <option>Sea Launch</option>
                <option>KARI</option>
                <option>ESA</option>
                <option>NASA</option>
                <option>Boeing</option>
                <option>ISAS</option>
                <option>SRC</option>
                <option>MITT</option>
                <option>Lockheed</option>
                <option>AEB</option>
                <option>Starsem</option>
                <option>RVSN USSR</option>
                <option>EER</option>
                <option>General Dynamics</option>
                <option>Martin Marietta</option>
                <option>Yuzhmash</option>
                <option>Douglas</option>
                <option>ASI</option>
                <option>US Air Force</option>
                <option>CNES</option>
                <option>CECLES</option>
                <option>RAE</option>
                <option>UT</option>
                <option>OKB-586</option>
                <option>AMBA</option>
                <option>Arm??e de l'Air</option>
                <option>US Navy</option>
</select>
<select class="select" name="status">
                    <option value="" disabled selected hidden>STATUS</option>
	            <option>Success</option>
                <option>Failure</option>
                <option>Prelaunch Failure</option>
                <option>Partial Failure</option>
</select>
<input class="link" type="submit" value="COMPARE">
</form><br><br>
<div>
    
    <?php
$servername = "localhost";
$username = "googlitt_space";
$password = "Majdi@0080010455";
$database = "googlitt_space";

$conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) {
        
        die("connection failed: " . $conn->connect_error);
    }

    if(isset($_GET['company'])) {
        
        $company = $_GET['company'];
        $status = $_GET['status'];
        $company2 = $_GET['company2'];
        $query = $conn->query("SELECT company, location, date, detail, status_rocket, rocket, status FROM space WHERE company LIKE '%{$company}%' AND status LIKE '%{$status}%'");
        
        $query2 = $conn->query("SELECT company, location, date, detail, status_rocket, rocket, status FROM space WHERE company LIKE '%{$company2}%' AND status LIKE '%{$status}%'");
        ?>
        <div><?php echo $query->num_rows; ?> Founded for <? echo $company ?> with <?php echo $status ?> missions</div><br>
        <div><?php echo $query2->num_rows; ?> Founded for <? echo $company2 ?> with <?php echo $status ?> missions</div><br>
<?php


            }
     
    
?>
<div style="font-size:14px;">The result based on our dataset and we are not sure yet from the accurate is this information. This is BETA version and we are still improving our data set.</div><br><h1>WAIT FOR NEW FEATURES!</h1>
<form action="index.php"><input class="link" type="submit" value="BACK TO SEARCH"></form>
</div>
</div>

</body>

</html>
