<html>
    <head>
        <title>Deep Dive in the Space Race | MAJDI AWAD</title>
        <style type="text/css">
            .body {
	            background-image:url('wallpaper.png');
            	background-position:center;
	            background-repeat:no-repeat;
	            background-attachment: fixed;
            }
            .search {
                width:300px;
                height:100%;
                padding:20px;
                background-color:rgba(255, 255, 255, 0.5);
                font-family:"Century Gothic";
                
            }
            .company {
                width:250px;
                height:50px;
                margin-top:10px;
                font-family:"Century Gothic";
            }
            .status {
                width:250px;
                height:50px;
                margin-top:10px;
                font-family:"Century Gothic";
            }
            .link {
                width:250px;
                height:50px;
                margin-top:10px;  
                background-color:#351306;
                color:#fff;
                font-size:16px;
                font-family:"Century Gothic";
                
            }
        </style>
    </head>
    <body class="body">
        <div align="center" class="search">
            <div><strong>Deep Dive in the Space Race</strong></div><br>
            <div style="font-size:11px;">Includes all the space missions since the beginning of Space Race (1957) - search over 4300 missions and discover the humanity achievements</div><br>
            <form action="action.php" method="get">
                <select class="company" name="company">
                <option value="" disabled selected hidden>Company Name</option>
                <option>SpaceX</option>
                <option>CASC</option>
                <option>Roscosmos</option>
                <option>ULA</option>
                <option>JAXA</option>
                <option>Northrop</option>
                <option>ExPace</option>
                <option>IAI</option>
                <option>Rocket Lab</option>
                <option>Virgin Orbit</option>
                <option>VKS RF</option>
                <option>MHI</option>
                <option>IRGC</option>
                <option>Arianespace</option>
                <option>ISA</option>
                <option>Blue Origin</option>
                <option>ISRO</option>
                <option>Exos</option>
                <option>ILS</option>
                <option>i-Space</option>
                <option>OneSpace</option>
                <option>Landspace</option>
                <option>Eurockot</option>
                <option>Land Launch</option>
                <option>CASIC</option>
                <option>KCST</option>
                <option>Sandia</option>
                <option>Kosmotras</option>
                <option>Khrunichev</option>
                <option>Sea Launch</option>
                <option>KARI</option>
                <option>ESA</option>
                <option>NASA</option>
                <option>Boeing</option>
                <option>ISAS</option>
                <option>SRC</option>
                <option>MITT</option>
                <option>Lockheed</option>
                <option>AEB</option>
                <option>Starsem</option>
                <option>RVSN USSR</option>
                <option>EER</option>
                <option>General Dynamics</option>
                <option>Martin Marietta</option>
                <option>Yuzhmash</option>
                <option>Douglas</option>
                <option>ASI</option>
                <option>US Air Force</option>
                <option>CNES</option>
                <option>CECLES</option>
                <option>RAE</option>
                <option>UT</option>
                <option>OKB-586</option>
                <option>AMBA</option>
                <option>Arm??e de l'Air</option>
                <option>US Navy</option>
                </select>
                <select class="status" name="status">
                <option value="" disabled selected hidden>Status Mission</option>
                <option>Success</option>
                <option>Failure</option>
                <option>Prelaunch Failure</option>
                <option>Partial Failure</option>
                </select>
                <input class="link" type="submit" name="submit" value="SEARCH NOW!">

            </form>
        <div style="font-size:11px;">This website will also allow you to make a comparison between companies. This is our BETA version and we will provide you with more options later.</div>
        <form action="compare.php">
            <input class="link" type="submit" value="COMPARE >>">
        </form>
        <div style="font-size:11px;">Also you will be able to find missions based on the location of the Launch. just type the country, city, or launch base get all missions.</div>
        <form action="location.php" method="get">
            <input class="status" type="text" name="location" placeholder="Country, cite, base ...">
            <input class="link" type="submit" value="SEARCH">
        </form>
        <form action="mars.php">
            <input class="link" type="submit" value="EXPLORE MARS">
        </form>
        
    </body>
</html>